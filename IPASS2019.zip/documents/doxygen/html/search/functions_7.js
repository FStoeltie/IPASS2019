var searchData=
[
  ['set_5frange_5fscale',['set_range_scale',['../class_graph_scene.html#a2d123bfb5cc206a179c04a70841e6a8f',1,'GraphScene']]],
  ['setiir',['setIIR',['../classbmp280.html#a379f05aa177d55e99bd3a098e2efced1',1,'bmp280']]],
  ['setmode',['setMode',['../classbmp280.html#a7304149cb12a908febd5ba9109ef2d5d',1,'bmp280']]],
  ['setoversampling',['setOversampling',['../classbmp280.html#afcbdb0160669a3d428e25bd715239fd5',1,'bmp280']]],
  ['setrotationindegrees',['setRotationInDegrees',['../class_graphics_object_square.html#afb2753b58b896a13f90e3269898a8a1d',1,'GraphicsObjectSquare']]],
  ['setscale',['setScale',['../class_graphics_object_square.html#a92fc26cdb800858992f505a57f31e3aa',1,'GraphicsObjectSquare::setScale()'],['../class_graph_scene.html#a1b84f3b649cd82142519771ceb94b04a',1,'GraphScene::setScale()']]],
  ['setsquaredata',['setSquareData',['../class_graphics_object_square.html#abc8b9bacc687ce180f6a03ea6c8ee69b',1,'GraphicsObjectSquare']]],
  ['setstandbytime',['setStandbyTime',['../classbmp280.html#a9a04623f32e2b3e8e175762e8863c41e',1,'bmp280']]]
];
