var searchData=
[
  ['primitives',['primitives',['../classhwlib_1_1i2c__bus.html#a676f1d61bce4122a7d446a42f749d567',1,'hwlib::i2c_bus']]]
];
