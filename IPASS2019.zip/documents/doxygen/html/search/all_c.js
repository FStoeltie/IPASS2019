var searchData=
[
  ['s_5f1',['S_1',['../bmp280_8hpp.html#a2db4a9862b3a2e31301ac185385d2520a9f15cdedd8d76e4abb50732f5727065b',1,'bmp280.hpp']]],
  ['s_5f2',['S_2',['../bmp280_8hpp.html#a2db4a9862b3a2e31301ac185385d2520aa3de00c1597600a387128a7add5b354f',1,'bmp280.hpp']]],
  ['s_5f4',['S_4',['../bmp280_8hpp.html#a2db4a9862b3a2e31301ac185385d2520a982f1877cdcf00febf7dbf67cc7a1229',1,'bmp280.hpp']]],
  ['scene_2ehpp',['scene.hpp',['../scene_8hpp.html',1,'']]],
  ['set_5frange_5fscale',['set_range_scale',['../class_graph_scene.html#a2d123bfb5cc206a179c04a70841e6a8f',1,'GraphScene']]],
  ['setiir',['setIIR',['../classbmp280.html#a379f05aa177d55e99bd3a098e2efced1',1,'bmp280']]],
  ['setmode',['setMode',['../classbmp280.html#a7304149cb12a908febd5ba9109ef2d5d',1,'bmp280']]],
  ['setoversampling',['setOversampling',['../classbmp280.html#afcbdb0160669a3d428e25bd715239fd5',1,'bmp280']]],
  ['setrotationindegrees',['setRotationInDegrees',['../class_graphics_object_square.html#afb2753b58b896a13f90e3269898a8a1d',1,'GraphicsObjectSquare']]],
  ['setscale',['setScale',['../class_graphics_object_square.html#a92fc26cdb800858992f505a57f31e3aa',1,'GraphicsObjectSquare::setScale()'],['../class_graph_scene.html#a1b84f3b649cd82142519771ceb94b04a',1,'GraphScene::setScale()']]],
  ['setsquaredata',['setSquareData',['../class_graphics_object_square.html#abc8b9bacc687ce180f6a03ea6c8ee69b',1,'GraphicsObjectSquare']]],
  ['setstandbytime',['setStandbyTime',['../classbmp280.html#a9a04623f32e2b3e8e175762e8863c41e',1,'bmp280']]],
  ['sleep',['SLEEP',['../bmp280_8hpp.html#a4fa86f9d2218a1052a2f337ec17984d3ab32bd403b93dc6deffdab7af55e82596',1,'bmp280.hpp']]],
  ['standby_5ftime',['STANDBY_TIME',['../bmp280_8hpp.html#a2db4a9862b3a2e31301ac185385d2520',1,'bmp280.hpp']]]
];
