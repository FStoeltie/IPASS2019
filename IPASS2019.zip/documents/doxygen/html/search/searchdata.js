var indexSectionsWithContent =
{
  0: "bcdfghimnoprstuvw~",
  1: "bgiv",
  2: "bhs",
  3: "bcdgiprsw~",
  4: "p",
  5: "imopst",
  6: "bfimnpstu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator"
};

